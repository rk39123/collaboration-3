#!/bin/bash

ros2 service call /reset_world std_srvs/srv/Empty