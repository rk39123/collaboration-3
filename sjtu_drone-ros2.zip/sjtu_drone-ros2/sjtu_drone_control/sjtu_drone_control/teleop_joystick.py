#!/usr/bin/env python3
# Copyright 2023 Georg Novotny
#
# Licensed under the GNU GENERAL PUBLIC LICENSE, Version 3.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.gnu.org/licenses/gpl-3.0.en.html
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import rclpy
from geometry_msgs.msg import Twist, Vector3
from rclpy.node import Node
from sensor_msgs.msg import Joy
from std_msgs.msg import Empty

class TeleopNode(Node):
    def __init__(self) -> None:
        super().__init__('teleop_node')
        self.create_subscription(Joy, 'joy', self.joy_callback, 0)
        # 퍼블리셔 토픽을 드론 플러그인 네임스페이스에 맞게 변경합니다.
        self.cmd_vel_publisher = self.create_publisher(Twist, '/simple_drone/cmd_vel', 10)
        self.takeoff_publisher = self.create_publisher(Empty, '/simple_drone/takeoff', 10)
        self.land_publisher = self.create_publisher(Empty, '/simple_drone/land', 10)

    def joy_callback(self, msg: Joy) -> None:
        linear_vec = Vector3(
            x=msg.axes[1],
            y=msg.axes[0],
            z=msg.axes[3]
        )
        angular_vec = Vector3(z=msg.axes[2])
        self.cmd_vel_publisher.publish(Twist(linear=linear_vec, angular=angular_vec))
        if msg.buttons[0] == 1:
            self.takeoff_publisher.publish(Empty())
        elif msg.buttons[1] == 1:
            self.cmd_vel_publisher.publish(Twist())
            self.land_publisher.publish(Empty())

def main(args=None):
    rclpy.init(args=args)
    try:
        teleop_node = TeleopNode()
        rclpy.spin(teleop_node)
    finally:
        teleop_node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
