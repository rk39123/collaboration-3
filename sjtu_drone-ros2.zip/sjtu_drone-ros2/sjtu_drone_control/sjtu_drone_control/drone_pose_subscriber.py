#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from nav_msgs.msg import Odometry
from geometry_msgs.msg import Point

class DronePoseSubscriber(Node):
    """
    드론의 /simple_drone/odom (예시) 토픽을 구독하여
    x,y,z 좌표를 drone_position 토픽(geometry_msgs/Point)으로 퍼블리시한다.
    """
    def __init__(self):
        super().__init__('drone_pose_subscriber')

        # 드론 오도메트리 토픽 구독
        self.subscription = self.create_subscription(
            Odometry,
            '/simple_drone/odom',  # 실제 드론 오도메트리 토픽 (플러그인/세팅에 따라 다를 수 있음)
            self.odom_callback,
            10
        )

        # 드론 좌표를 퍼블리시할 토픽 (Point 메시지)
        self.pose_publisher = self.create_publisher(Point, 'drone_position', 10)

        self.get_logger().info('DronePoseSubscriber node started!')

    def odom_callback(self, msg: Odometry):
        # 오도메트리에서 x,y,z 추출
        x = msg.pose.pose.position.x
        y = msg.pose.pose.position.y
        z = msg.pose.pose.position.z

        # Point 메시지 생성 후 퍼블리시
        point_msg = Point(x=x, y=y, z=z)
        self.pose_publisher.publish(point_msg)

def main(args=None):
    rclpy.init(args=args)
    node = DronePoseSubscriber()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
