#!/usr/bin/env python3

import os

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, SetEnvironmentVariable, IncludeLaunchDescription
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch.launch_description_sources import PythonLaunchDescriptionSource
from ament_index_python.packages import get_package_share_directory

def generate_launch_description():
    ############################################################################
    # 1) 터틀봇3 모델 환경변수 설정
    ############################################################################
    set_turtlebot3_model = SetEnvironmentVariable(
        name='TURTLEBOT3_MODEL',
        value='waffle'  # 원하는 모델 (waffle, waffle_pi 등)
    )

    ############################################################################
    # 2) TurtleBot3 Manipulation 'gazebo.launch.py'에서 사용하던 인자들 정의
    ############################################################################
    start_rviz = LaunchConfiguration('start_rviz')
    prefix = LaunchConfiguration('prefix')
    use_sim = LaunchConfiguration('use_sim')

    # 여기서 "원하는 world" 경로를 지정 (예: sjtu_drone_description 내 warehouse.world)
    world = LaunchConfiguration(
        'world',
        default=PathJoinSubstitution([
            get_package_share_directory('sjtu_drone_description'),
            'worlds',
            'warehouse_mines_v0.0_w_color',
            'warehouse.world'
        ])
    )

    x_pose = LaunchConfiguration('x_pose', default='-2.00')
    y_pose = LaunchConfiguration('y_pose', default='-0.50')
    z_pose = LaunchConfiguration('z_pose', default='0.01')
    roll  = LaunchConfiguration('roll',  default='0.00')
    pitch = LaunchConfiguration('pitch', default='0.00')
    yaw   = LaunchConfiguration('yaw',   default='0.00')

    declare_args = [
        DeclareLaunchArgument('start_rviz', default_value='false',
                              description='Whether execute rviz2'),
        DeclareLaunchArgument('prefix', default_value='""',
                              description='Prefix of the joint and link names'),
        DeclareLaunchArgument('use_sim', default_value='true',
                              description='Start robot in Gazebo simulation.'),
        DeclareLaunchArgument('world', default_value=world,
                              description='Directory of gazebo world file'),
        DeclareLaunchArgument('x_pose', default_value=x_pose,
                              description='position of turtlebot3'),
        DeclareLaunchArgument('y_pose', default_value=y_pose,
                              description='position of turtlebot3'),
        DeclareLaunchArgument('z_pose', default_value=z_pose,
                              description='position of turtlebot3'),
        DeclareLaunchArgument('roll',   default_value=roll,
                              description='orientation of turtlebot3'),
        DeclareLaunchArgument('pitch',  default_value=pitch,
                              description='orientation of turtlebot3'),
        DeclareLaunchArgument('yaw',    default_value=yaw,
                              description='orientation of turtlebot3'),
    ]

    ############################################################################
    # 3) turtlebot3_manipulation_bringup의 base.launch.py + Gazebo 로드
    ############################################################################
    manipulation_pkg = get_package_share_directory('turtlebot3_manipulation_bringup')

    # base.launch.py
    base_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(manipulation_pkg, 'launch', 'base.launch.py')
        ),
        launch_arguments={
            'start_rviz': start_rviz,
            'prefix': prefix,
            'use_sim': use_sim,
        }.items(),
    )

    # gazebo_ros/launch/gazebo.launch.py
    gazebo_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(
                get_package_share_directory('gazebo_ros'),
                'launch',
                'gazebo.launch.py'
            )
        ),
        launch_arguments={
            'verbose': 'false',
            'world': world  # 커스텀 world 반영
        }.items(),
    )

    # 로봇팔+터틀봇3를 스폰 (spawn_entity.py)
    spawn_manipulation_system = Node(
        package='gazebo_ros',
        executable='spawn_entity.py',
        arguments=[
            '-topic', 'robot_description',
            '-entity', 'turtlebot3_manipulation_system',
            '-x', x_pose,
            '-y', y_pose,
            '-z', z_pose,
            '-R', roll,
            '-P', pitch,
            '-Y', yaw,
        ],
        output='screen',
    )

    ############################################################################
    # 4) 드론 런치 포함 (sjtu_drone_bringup)
    ############################################################################
    drone_pkg_share = get_package_share_directory('sjtu_drone_bringup')
    drone_launch_file = os.path.join(drone_pkg_share, 'launch', 'sjtu_drone_bringup.launch.py')

    drone_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(drone_launch_file),
        launch_arguments={}.items()  # 필요 시 인자 추가
    )

    ############################################################################
    # 5) LaunchDescription에 모두 추가
    ############################################################################
    return LaunchDescription(
        [set_turtlebot3_model]               # 터틀봇3 모델 설정
        + declare_args                       # 인자 선언
        + [
            base_launch,                    # turtlebot3_manipulation_bringup/launch/base.launch.py
            gazebo_launch,                  # gazebo_ros/launch/gazebo.launch.py (커스텀 world)
            spawn_manipulation_system,      # 로봇팔+터틀봇3 스폰
            drone_launch                    # 드론 런치
        ]
    )
