#!/usr/bin/env python3
#
# Copyright 2019 Open Source Robotics Foundation
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node

def generate_launch_description():
    TURTLEBOT3_MODEL = os.environ['TURTLEBOT3_MODEL']

    # 드론과 유사한 좌표로 터틀봇의 초기 위치 지정
    x_pose = LaunchConfiguration('x_pose', default='-1.013570')
    y_pose = LaunchConfiguration('y_pose', default='3.022503')

    declare_x_position_cmd = DeclareLaunchArgument(
        'x_pose', default_value='-1.013570',
        description='x position of the turtlebot'
    )

    declare_y_position_cmd = DeclareLaunchArgument(
        'y_pose', default_value='3.022503',
        description='y position of the turtlebot'
    )

    start_turtlebot3_spawner_cmd = Node(
        package='gazebo_ros',
        executable='spawn_entity.py',
        arguments=[
            '-entity', TURTLEBOT3_MODEL,
            '-topic', 'robot_description',  # URDF가 퍼블리시된 토픽 사용
            '-x', x_pose,
            '-y', y_pose,
            '-z', '0.01'
        ],
        output='screen',
    )

    ld = LaunchDescription()
    ld.add_action(declare_x_position_cmd)
    ld.add_action(declare_y_position_cmd)
    ld.add_action(start_turtlebot3_spawner_cmd)

    return ld
